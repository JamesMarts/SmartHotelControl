package hotel.suozhang.com.jsapp;

import android.content.Context;
import android.webkit.WebView;

/**
 * TODO: document your custom view class.
 */
public class MyWebView extends WebView {

    public MyWebView(Context context) {
        super(context);
    }


}
